import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'logic/notifiers/food_notifier.dart';
import 'logic/notifiers/meal_notifier.dart';
import 'logic/notifiers/user_notifier.dart';
import 'logic/notifiers/theme_notifier.dart';

import 'presentation/screens/main_wrapper.dart';
import 'presentation/screens/auth/login_screen.dart'; // Import Login
import 'presentation/screens/onboarding/onboarding_screen.dart'; // Import Onboarding

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (e) {
    debugPrint("Firebase init failed (options missing?): $e");
  }

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => FoodNotifier()),
        ChangeNotifierProvider(create: (_) => MealNotifier()),
        ChangeNotifierProvider(
          create: (_) => UserNotifier()..initUserListener(),
        ), // Init Listener
        ChangeNotifierProvider(create: (_) => ThemeNotifier()),
      ],
      child: Consumer<ThemeNotifier>(
        builder: (context, themeNotifier, child) {
          return MaterialApp(
            title: 'FoodKai',
            debugShowCheckedModeBanner: false,
            // Light & Dark Theme Logic
            theme: AppTheme.theme,
            darkTheme: AppTheme.darkTheme,
            themeMode: themeNotifier.isDarkMode
                ? ThemeMode.dark
                : ThemeMode.light,
            // Simple Route Management
            routes: {
              '/login': (context) => const LoginScreen(),
              '/home': (context) => const MainWrapper(),
              '/onboarding': (context) => const OnboardingScreen(),
            },
            home: const LoginScreen(), // Start at Login
          );
        },
      ),
    ),
  );
}
