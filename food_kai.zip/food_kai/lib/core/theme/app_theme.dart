import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Pastel Palette
  static const Color softMint = Color(0xFF81D4C2);
  static const Color lightCoral = Color(0xFFFFADAD);
  static const Color creamyWhite = Color(0xFFFAFAFA); // Snow White
  static const Color darkText = Color(0xFF2D3436);
  static const Color subText = Color(0xFF636E72);
  static const Color accentBlue = Color(0xFFA0C4FF);

  // Dark Mode Colors
  static const Color deepCharcoal = Color(0xFF121212);
  static const Color darkCard = Color(0xFF1E1E1E);
  static const Color offWhite = Color(0xFFF5F5F5);

  // Sunset Gradient
  static const Color sunsetStart = Color(0xFFFFE0B2);
  static const Color sunsetEnd = Color(0xFFFFCCBC);

  // Shadows
  static List<BoxShadow> softShadow = [
    BoxShadow(
      color: Colors.black.withOpacity(0.05),
      blurRadius: 10,
      spreadRadius: 2,
      offset: const Offset(0, 4),
    ),
  ];

  static ThemeData get theme {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: creamyWhite,
      primaryColor: softMint,
      textTheme: GoogleFonts.poppinsTextTheme().apply(
        bodyColor: darkText,
        displayColor: darkText,
      ),
      colorScheme: ColorScheme.fromSeed(
        seedColor: softMint,
        surface: creamyWhite,
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      ),
    );
  }

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: deepCharcoal, // Dark Background
      primaryColor: softMint,
      brightness: Brightness.dark,
      textTheme: GoogleFonts.poppinsTextTheme().apply(
        bodyColor: offWhite,
        displayColor: offWhite,
      ),
      colorScheme: ColorScheme.fromSeed(
        seedColor: softMint,
        brightness: Brightness.dark,
        surface: deepCharcoal,
      ),
      cardTheme: CardThemeData(
        color: darkCard, // Dark Card
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: offWhite),
        titleTextStyle: TextStyle(
          color: offWhite,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      iconTheme: const IconThemeData(color: offWhite),
    );
  }
}
