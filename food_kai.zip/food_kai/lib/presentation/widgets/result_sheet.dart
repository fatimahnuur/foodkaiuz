import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../logic/notifiers/food_notifier.dart';
import '../../core/theme/app_theme.dart';
import 'nutri_advisor_card.dart';
import 'ingredient_item.dart';

class ResultSheet extends StatelessWidget {
  final ScrollController? scrollController;
  const ResultSheet({super.key, this.scrollController});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
      child: Column(
        children: [
          // Drag Handle
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 24),

          Expanded(
            child: Consumer<FoodNotifier>(
              builder: (context, notifier, child) {
                final food = notifier.scannedFood;
                if (food == null) return const SizedBox();

                return ListView(
                  controller: scrollController,
                  padding: EdgeInsets.zero,
                  children: [
                    // Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Calories Remaining',
                              style: Theme.of(context).textTheme.bodySmall
                                  ?.copyWith(color: AppTheme.subText),
                            ),
                            Text(
                              food.totalCalories.toInt().toString(),
                              style: Theme.of(context).textTheme.displayMedium
                                  ?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: AppTheme.darkText,
                                    height: 1.0,
                                  ),
                            ),
                          ],
                        ),

                        // Source Badge and Calorie Text
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              margin: const EdgeInsets.only(bottom: 4),
                              decoration: BoxDecoration(
                                color: notifier.dataMode == DataMode.cloud
                                    ? AppTheme.accentBlue.withOpacity(0.2)
                                    : Colors.green.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                notifier.dataMode == DataMode.cloud
                                    ? 'Source: Firebase'
                                    : 'Source: Local Storage',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: notifier.dataMode == DataMode.cloud
                                      ? AppTheme.accentBlue
                                      : Colors.green,
                                ),
                              ),
                            ),
                            Text(
                              '${food.totalCalories.toInt()} / 2000 kcal',
                              style: Theme.of(context).textTheme.bodyMedium
                                  ?.copyWith(color: AppTheme.subText),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),

                    // Progress Bar
                    Container(
                      height: 8,
                      decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: (food.totalCalories / 2000).clamp(
                          0.0,
                          1.0,
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            color: AppTheme.softMint.withOpacity(
                              0.8,
                            ), // Darken slightly for visibility if needed, or use primary
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Macros Row
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _MacroBadge(
                          label: 'Protein',
                          value: food.totalProtein,
                          color: Colors.green.shade700,
                        ),
                        _MacroBadge(
                          label: 'Carbs',
                          value: food.totalCarbs,
                          color: Colors.amber.shade700,
                        ),
                        _MacroBadge(
                          label: 'Fats',
                          value: food.totalFat,
                          color: Colors.redAccent.shade200,
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Today's Recommendations Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Today's Recommendations",
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        Icon(Icons.filter_list, color: AppTheme.darkText),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // Tags (Mockup)
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _buildTag('No Peanuts'),
                          const SizedBox(width: 8),
                          _buildTag('Gluten-Free'),
                          const SizedBox(width: 8),
                          _buildTag('High Protein'),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Ingredients Grid
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            childAspectRatio: 0.8,
                            crossAxisSpacing: 16,
                            mainAxisSpacing: 16,
                          ),
                      itemCount: food.ingredients.length,
                      itemBuilder: (context, index) {
                        return IngredientItem(index: index);
                      },
                    ),
                    const SizedBox(height: 24),

                    // Nutri Advisor
                    const NutriAdvisorCard(),

                    const SizedBox(height: 32),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTag(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F2F6),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.transparent),
      ),
      child: Row(
        children: [
          Icon(Icons.check, size: 16, color: Colors.green[800]),
          const SizedBox(width: 4),
          Text(
            text,
            style: TextStyle(
              color: Colors.green[800],
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class _MacroBadge extends StatelessWidget {
  final String label;
  final double value;
  final Color color;

  const _MacroBadge({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          '${value.toInt()}g',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
        Container(
          margin: const EdgeInsets.only(top: 4),
          width: 40,
          height: 4,
          decoration: BoxDecoration(
            color: color.withOpacity(0.3),
            borderRadius: BorderRadius.circular(2),
          ),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor:
                1.0, // Just full width for badge style, or could be ratio
            child: Container(
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
