import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../logic/notifiers/food_notifier.dart';
import '../../core/theme/app_theme.dart';
import 'custom_stepper.dart';

class IngredientItem extends StatelessWidget {
  final int index;

  const IngredientItem({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    return Consumer<FoodNotifier>(
      builder: (context, notifier, child) {
        final ingredient = notifier.scannedFood!.ingredients[index];

        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: AppTheme.softShadow,
          ),
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Icon & Name
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.creamyWhite,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.restaurant,
                      color: AppTheme.softMint,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      ingredient.name,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              // Calories
              Text(
                '${ingredient.totalCalories.toInt()} kcal',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppTheme.subText,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              // Stepper
              Center(
                child: CustomStepper(
                  value: ingredient.weightGrams,
                  onChanged: (newVal) {
                    notifier.updateIngredientWeight(index, newVal);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
