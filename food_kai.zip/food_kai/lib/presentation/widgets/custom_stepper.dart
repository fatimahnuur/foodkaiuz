import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

class CustomStepper extends StatelessWidget {
  final double value;
  final ValueChanged<double> onChanged;
  final double step;

  const CustomStepper({
    super.key,
    required this.value,
    required this.onChanged,
    this.step = 10.0,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildButton(Icons.remove, () {
          if (value > 0) onChanged(value - step);
        }),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12.0),
          child: Text(
            '${value.toInt()}g',
            style: Theme.of(
              context,
            ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
        ),
        _buildButton(Icons.add, () {
          onChanged(value + step);
        }, isAdd: true),
      ],
    );
  }

  Widget _buildButton(IconData icon, VoidCallback onTap, {bool isAdd = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: isAdd ? AppTheme.softMint : const Color(0xFFF1F2F6),
          shape: BoxShape.circle,
        ),
        child: Icon(
          icon,
          size: 16,
          color: isAdd ? Colors.white : AppTheme.subText,
        ),
      ),
    );
  }
}
