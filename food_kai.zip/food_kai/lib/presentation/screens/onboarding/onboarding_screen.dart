import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // For HapticFeedback
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../../logic/notifiers/user_notifier.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  // Form Keys
  final _measurementsFormKey = GlobalKey<FormState>();
  final _goalFormKey = GlobalKey<FormState>();

  // State
  String _gender = 'Male';
  late TextEditingController _ageController;
  late TextEditingController _heightController;
  late TextEditingController _weightController;
  String _goal = 'Lose Weight';
  String _activity = 'Sedentary';

  final int _totalPages = 4;

  @override
  void initState() {
    super.initState();
    _ageController = TextEditingController(text: '25');
    _heightController = TextEditingController(text: '175');
    _weightController = TextEditingController(text: '70');
  }

  @override
  void dispose() {
    _pageController.dispose();
    _ageController.dispose();
    _heightController.dispose();
    _weightController.dispose();
    super.dispose();
  }

  // --- VALIDATORS ---
  String? _validateAge(String? value) {
    if (value == null || value.isEmpty) return 'Required';
    final n = int.tryParse(value);
    if (n == null || n < 12 || n > 100) return 'Range: 12 - 100 years';
    return null;
  }

  String? _validateHeight(String? value) {
    if (value == null || value.isEmpty) return 'Required';
    final n = double.tryParse(value);
    if (n == null || n < 100 || n > 250) return 'Range: 100 - 250 cm';
    return null;
  }

  String? _validateWeight(String? value) {
    if (value == null || value.isEmpty) return 'Required';
    final n = double.tryParse(value);
    if (n == null || n < 30 || n > 300) return 'Range: 30 - 300 kg';
    return null;
  }

  void _nextPage() {
    // Validation Logic
    if (_currentPage == 1) {
      if (!_measurementsFormKey.currentState!.validate()) {
        HapticFeedback.vibrate();
        return;
      }
    } else if (_currentPage == 2) {
      if (!_goalFormKey.currentState!.validate()) {
        HapticFeedback.vibrate();
        return;
      }

      // Safety Logic Check for Goal
      final weight = double.tryParse(_weightController.text) ?? 0;
      final height = double.tryParse(_heightController.text) ?? 0;
      double bmi = 0;
      if (height > 0) {
        bmi = weight / ((height / 100) * (height / 100));
      }

      if (bmi < 18.5 && _goal == 'Lose Weight') {
        HapticFeedback.mediumImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Your BMI is low. We recommend "Maintain" or "Gain Muscle".',
            ),
            backgroundColor: Colors.orange,
            duration: Duration(seconds: 3),
          ),
        );
        // We warn but allow proceed? Or block?
        // User requested: "warn against choosing". Let's block "Lose Weight" only if they persist or just warn.
        // Let's warn and allow them to change, but if they click Next again immediately it might be annoying.
        // Simplest safe approach: Show warning. If they really want to proceed, they might need to change goal.
        return;
      }
    }

    if (_currentPage < _totalPages - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      _finishOnboarding();
    }
  }

  Future<void> _finishOnboarding() async {
    final age = int.parse(_ageController.text);
    final height = double.parse(_heightController.text);
    final weight = double.parse(_weightController.text);

    final notifier = context.read<UserNotifier>();
    await notifier.updateUserData(
      gender: _gender,
      age: age,
      height: height,
      weight: weight,
      goal: _goal,
      activityLevel: _activity,
    );
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/home');
    }
  }

  @override
  Widget build(BuildContext context) {
    double progress = (_currentPage + 1) / _totalPages;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Progress Bar
            LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.grey[200],
              color: AppTheme.softMint,
              minHeight: 6,
            ),

            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                onPageChanged: (p) => setState(() => _currentPage = p),
                children: [
                  _buildGenderPage(),
                  _buildMeasurementsPage(),
                  _buildGoalPage(),
                  _buildActivityPage(),
                ],
              ),
            ),

            // Navigation Buttons
            Padding(
              padding: const EdgeInsets.all(24),
              child: Row(
                children: [
                  if (_currentPage > 0)
                    IconButton(
                      onPressed: () {
                        _pageController.previousPage(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut,
                        );
                      },
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: AppTheme.subText,
                      ),
                    )
                  else
                    const SizedBox(width: 48), // Spacer
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _nextPage,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.softMint,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 4,
                        shadowColor: AppTheme.softMint.withOpacity(0.4),
                      ),
                      child: Text(
                        _currentPage == _totalPages - 1
                            ? 'Start Journey'
                            : 'Next',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // PAGES

  Widget _buildGenderPage() {
    return _buildPageLayout(
      title: "What's your gender?",
      subtitle: "This helps us calculate your BMR accurately.",
      content: Column(
        children: [
          _buildSelectableCard(
            'Male',
            Icons.male,
            _gender == 'Male',
            () => setState(() => _gender = 'Male'),
          ),
          const SizedBox(height: 16),
          _buildSelectableCard(
            'Female',
            Icons.female,
            _gender == 'Female',
            () => setState(() => _gender = 'Female'),
          ),
        ],
      ),
      didYouKnow:
          "Men typically have more muscle mass, which means they burn more calories at rest!",
    );
  }

  Widget _buildMeasurementsPage() {
    return _buildPageLayout(
      title: "Your Body Stats",
      subtitle: "Let's get your baseline.",
      content: Form(
        key: _measurementsFormKey,
        child: Column(
          children: [
            _buildNumericInput(
              "Age",
              Icons.cake_outlined,
              _ageController,
              "years",
              _validateAge,
            ),
            const SizedBox(height: 16),
            _buildNumericInput(
              "Height",
              Icons.height,
              _heightController,
              "cm",
              _validateHeight,
            ),
          ],
        ),
      ),
      didYouKnow:
          "Height plays a major role in your TDEE (Total Daily Energy Expenditure). Taller people burn more energy!",
    );
  }

  Widget _buildGoalPage() {
    return _buildPageLayout(
      title: "What is your goal?",
      subtitle: "We'll adjust your calories accordingly.",
      content: Form(
        key: _goalFormKey,
        child: Column(
          children: [
            _buildNumericInput(
              "Current Weight",
              Icons.monitor_weight_outlined,
              _weightController,
              "kg",
              _validateWeight,
            ),
            const SizedBox(height: 24),
            _buildDropdown("Goal", _goal, [
              'Lose Weight',
              'Maintain Weight',
              'Gain Muscle',
            ], (v) => setState(() => _goal = v!)),
          ],
        ),
      ),
      didYouKnow:
          "Calories are units of energy. To lose weight, you need a 'Deficit' (eating less than you burn). To gain muscle, you need a 'Surplus'. Your goal determines this balance!",
    );
  }

  Widget _buildActivityPage() {
    return _buildPageLayout(
      title: "How active are you?",
      subtitle: "Be honest! This changes everything.",
      content: Column(
        children: [
          _buildActivityCard('Sedentary', Icons.chair, 'Office job, relax'),
          const SizedBox(height: 12),
          _buildActivityCard(
            'Lightly Active',
            Icons.directions_walk,
            '1-3 days/week',
          ),
          const SizedBox(height: 12),
          _buildActivityCard(
            'Moderately Active',
            Icons.directions_run,
            '3-5 days/week',
          ),
          const SizedBox(height: 12),
          _buildActivityCard(
            'Very Active',
            Icons.directions_bike,
            '6-7 days/week',
          ),
        ],
      ),
      didYouKnow:
          "Your Activity Level multiplies your BMR. A 'Very Active' person can burn 500+ more calories a day than a 'Sedentary' person, even at rest!",
    );
  }

  // WIDGET HELPERS

  Widget _buildActivityCard(String level, IconData icon, String desc) {
    final isSelected = _activity == level;
    return GestureDetector(
      onTap: () => setState(() => _activity = level),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.softMint : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? Colors.transparent : Colors.grey[200]!,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppTheme.softMint.withOpacity(0.4),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: isSelected
                    ? Colors.white.withOpacity(0.2)
                    : Colors.grey[100],
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                color: isSelected ? Colors.white : AppTheme.softMint,
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    level,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: isSelected ? Colors.white : AppTheme.darkText,
                    ),
                  ),
                  Text(
                    desc,
                    style: TextStyle(
                      fontSize: 12,
                      color: isSelected ? Colors.white70 : AppTheme.subText,
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected) const Icon(Icons.check_circle, color: Colors.white),
          ],
        ),
      ),
    );
  }

  Widget _buildPageLayout({
    required String title,
    required String subtitle,
    required Widget content,
    required String didYouKnow,
  }) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          Text(
            title,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: AppTheme.darkText,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            style: Theme.of(
              context,
            ).textTheme.bodyLarge?.copyWith(color: AppTheme.subText),
          ),
          const SizedBox(height: 40),
          content,
          const SizedBox(height: 40),
          // Info Box
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.blue[50],
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.blue[100]!),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.lightbulb, color: Colors.blue, size: 24),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Did you know?",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        didYouKnow,
                        style: TextStyle(color: Colors.blue[800], fontSize: 13),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSelectableCard(
    String title,
    IconData icon,
    bool isSelected,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.softMint : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? AppTheme.softMint : Colors.grey[200]!,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppTheme.softMint.withOpacity(0.4),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [],
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isSelected ? Colors.white : AppTheme.subText,
              size: 28,
            ),
            const SizedBox(width: 16),
            Text(
              title,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isSelected ? Colors.white : AppTheme.darkText,
              ),
            ),
            const Spacer(),
            if (isSelected) const Icon(Icons.check_circle, color: Colors.white),
          ],
        ),
      ),
    );
  }

  Widget _buildNumericInput(
    String label,
    IconData icon,
    TextEditingController controller,
    String suffix,
    String? Function(String?)? validator,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: AppTheme.softShadow,
      ),
      child: TextFormField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Theme.of(context).textTheme.bodyLarge?.color,
          fontFamily: 'Poppins',
        ),
        validator: validator,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        decoration: InputDecoration(
          border: InputBorder.none,
          icon: Icon(icon, color: AppTheme.softMint, size: 28),
          labelText: label,
          labelStyle: const TextStyle(color: AppTheme.subText, fontSize: 14),
          suffixText: suffix,
          suffixStyle: const TextStyle(
            color: AppTheme.subText,
            fontWeight: FontWeight.bold,
          ),
          errorStyle: const TextStyle(
            color: Colors.red,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown(
    String label,
    String value,
    List<String> items,
    ValueChanged<String?> onChanged,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: AppTheme.softShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(color: AppTheme.subText, fontSize: 12),
          ),
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              icon: const Icon(Icons.arrow_drop_down, color: AppTheme.subText),
              items: items
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }
}
