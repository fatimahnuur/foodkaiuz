import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../logic/notifiers/food_notifier.dart';
import '../widgets/result_sheet.dart';
import 'home_screen.dart';
import 'profile_screen.dart';
import 'scan_screen.dart';

class MainWrapper extends StatefulWidget {
  const MainWrapper({super.key});

  @override
  State<MainWrapper> createState() => _MainWrapperState();
}

class _MainWrapperState extends State<MainWrapper> {
  int _currentIndex = 0;

  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      const HomeScreen(),
      const SizedBox(), // Placeholder for Scanner
      const ProfileScreen(),
    ];
  }

  void _onScanPressed() {
    // Push Scanner as a helper modal/page
    Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const ScanScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: IndexedStack(index: _currentIndex, children: _pages),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Always push scanner, don't change tab index to 1
          _onScanPressed();
        },
        backgroundColor: Colors.white,
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Theme.of(context).cardColor,
            border: Border.all(color: AppTheme.softMint, width: 2),
            boxShadow: [
              BoxShadow(
                color: AppTheme.softMint.withOpacity(0.3),
                blurRadius: 8,
                spreadRadius: 2,
              ),
            ],
          ),
          child: const Icon(
            Icons.qr_code_scanner,
            color: AppTheme.softMint,
            size: 28,
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              spreadRadius: 0,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          child: BottomAppBar(
            shape: const CircularNotchedRectangle(),
            notchMargin: 10.0,
            color: Theme.of(context).cardColor,
            elevation: 0,
            surfaceTintColor: Theme.of(context).cardColor,
            child: SizedBox(
              height: 60,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  IconButton(
                    icon: Icon(
                      _currentIndex == 0 ? Icons.home : Icons.home_outlined,
                      color: _currentIndex == 0
                          ? AppTheme.softMint
                          : AppTheme.subText,
                      size: 30,
                    ),
                    onPressed: () => setState(() => _currentIndex = 0),
                  ),
                  const SizedBox(width: 48), // Space for FAB
                  IconButton(
                    icon: Icon(
                      _currentIndex == 2
                          ? Icons.settings
                          : Icons.settings_outlined,
                      color: _currentIndex == 2
                          ? AppTheme.softMint
                          : AppTheme.subText,
                      size: 30,
                    ),
                    onPressed: () => setState(() => _currentIndex = 2),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
