import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:food_kai/core/theme/app_theme.dart';
import '../../logic/services/yolo_service.dart';
import '../../logic/notifiers/food_notifier.dart';
import '../widgets/result_sheet.dart';

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> with TickerProviderStateMixin {
  late AnimationController _lineController;
  late Animation<double> _lineAnimation;
  CameraController? _controller;
  final ImagePicker _picker = ImagePicker();
  final YoloService _yoloService = YoloService();

  bool _isCameraInitialized = false;
  bool _isDetecting = false;
  String? _errorMessage;
  String _statusMessage = 'Initializing...';

  @override
  void initState() {
    super.initState();
    _lineController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _lineAnimation = Tween<double>(begin: 0.1, end: 0.9).animate(
      CurvedAnimation(parent: _lineController, curve: Curves.easeInOut),
    );

    _initialize();
  }

  Future<void> _initialize() async {
    await _yoloService.loadModel();
    await _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    if (!mounted) return;
    setState(() {
      _errorMessage = null;
      _statusMessage = 'Checking permissions...';
      _isCameraInitialized = false;
    });

    await _checkPermissions();
  }

  Future<void> _checkPermissions() async {
    try {
      var cameraStatus = await Permission.camera.request();
      var audioStatus = await Permission.microphone.request();

      if (cameraStatus.isGranted) {
        _initCamera();
      } else {
        if (mounted) {
          setState(() {
            _errorMessage = 'Ruxsat berilmadi.';
            _statusMessage = 'Permission denied';
          });
        }
      }
    } catch (e) {
      if (mounted) setState(() => _errorMessage = 'Permission error: $e');
    }
  }

  Future<void> _initCamera() async {
    try {
      setState(() => _statusMessage = 'Looking for cameras...');
      final cameras = await availableCameras();

      if (cameras.isEmpty) {
        if (mounted) setState(() => _errorMessage = 'Kamera topilmadi');
        return;
      }

      final firstCamera = cameras.firstWhere(
        (camera) => camera.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );

      _controller = CameraController(
        firstCamera,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.yuv420,
      );

      setState(() => _statusMessage = 'Initializing controller...');
      await _controller!.initialize();

      _controller!.startImageStream((image) {
        if (!_isDetecting && _yoloService.isLoaded) {
          _isDetecting = true;
          _runModelOnFrame(image);
        }
      });

      if (mounted) {
        setState(() {
          _isCameraInitialized = true;
          _errorMessage = null;
          _statusMessage = 'Ready';
        });
      }
    } catch (e) {
      if (mounted) setState(() => _errorMessage = 'Camera Error: $e');
    }
  }

  // Mocking Logic for Screenshot
  Future<void> _runModelOnFrame(CameraImage image) async {
    // 1. Disable actual model
    // await Future.delayed(const Duration(milliseconds: 500));
    // ... yoloService.detectOnFrame ...

    // 2. Mock Delay and Result
    if (!_isDetecting) return;

    // Run this only once to simulate "Finding"
    if (_statusMessage != 'Found!') {
      await Future.delayed(const Duration(seconds: 2));
      if (!mounted) return;

      setState(() {
        _statusMessage = 'Found!';
        // _isScanningUI = false; // Stop animation if we had one
      });

      print("Mock Detection: CinnamonRolls");
      Provider.of<FoodNotifier>(
        context,
        listen: false,
      ).lookupFood('CinnamonRolls');

      // Force open sheet? built-in via Stack below
    }
  }

  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
      if (image == null) return;

      setState(() {
        _isDetecting = true;
        _statusMessage = 'Analyzing gallery image...';
      });

      final result = await _yoloService.detectOnImage(image.path);

      if (!mounted) return;

      if (result != null) {
        setState(() {
          _statusMessage = 'Found!';
        });
        print("Gallery Detection: ${result['label']}");
        Provider.of<FoodNotifier>(
          context,
          listen: false,
        ).lookupFood(result['label']);
      } else {
        setState(() {
          _statusMessage = 'Ready';
          _isDetecting = false;
        });
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('No food detected')));
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMessage = 'Gallery error: $e';
          _isDetecting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          if (_isCameraInitialized && _controller != null)
            SizedBox.expand(child: CameraPreview(_controller!))
          else
            _buildPlaceholder(),

          // Scanning Overlay
          if (_statusMessage != 'Found!') _buildScanLine(),

          if (_statusMessage != 'Found!')
            Align(
              alignment: Alignment.center,
              child: Text(
                "Scanning...",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.8),
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                  shadows: [Shadow(blurRadius: 10, color: Colors.black)],
                ),
              ),
            ),

          _buildHeader(),

          // Force Open Sheet (Mocking the modal bottom sheet behavior but permanent for screenshot)
          if (_statusMessage == 'Found!')
            DraggableScrollableSheet(
              initialChildSize: 0.6,
              minChildSize: 0.1,
              maxChildSize: 0.9,
              builder: (context, scrollController) {
                return ResultSheet(scrollController: scrollController);
              },
            ),
        ],
      ),
    );
  }

  Widget _buildPlaceholder() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF2D3436), Colors.black],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_errorMessage != null) ...[
              const Icon(
                Icons.error_outline,
                color: Colors.orangeAccent,
                size: 48,
              ),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Text(
                  _errorMessage!,
                  style: const TextStyle(color: Colors.white),
                  textAlign: TextAlign.center,
                ),
              ),
              ElevatedButton.icon(
                onPressed: () {
                  _initializeCamera();
                  _initialize();
                }, // Re-init all
                icon: const Icon(Icons.refresh),
                label: const Text('Qayta urinish'),
              ),
            ] else ...[
              const CircularProgressIndicator(color: AppTheme.softMint),
              const SizedBox(height: 20),
              Text(
                _statusMessage,
                style: const TextStyle(color: Colors.white70),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildScanLine() {
    return AnimatedBuilder(
      animation: _lineAnimation,
      builder: (context, child) {
        return Align(
          alignment: Alignment(0, _lineAnimation.value * 2 - 1),
          child: Container(
            height: 2,
            width: double.infinity,
            margin: const EdgeInsets.symmetric(horizontal: 24),
            decoration: BoxDecoration(
              color: AppTheme.softMint,
              boxShadow: [
                BoxShadow(
                  color: AppTheme.softMint.withOpacity(0.8),
                  blurRadius: 10,
                  spreadRadius: 2,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: const Icon(Icons.arrow_back, color: Colors.white),
            ),
            const Spacer(),
            Consumer<FoodNotifier>(
              builder: (context, notifier, child) {
                final isCloud = notifier.dataMode == DataMode.cloud;
                return Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.black45,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () => notifier.setMode(DataMode.cloud),
                        child: Text(
                          "  Online  ",
                          style: TextStyle(
                            color: isCloud ? AppTheme.softMint : Colors.grey,
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () => notifier.setMode(DataMode.local),
                        child: Text(
                          "  Offline  ",
                          style: TextStyle(
                            color: !isCloud ? AppTheme.softMint : Colors.grey,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
            const Spacer(),
            GestureDetector(
              onTap: _pickImage,
              child: const Icon(Icons.image, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
