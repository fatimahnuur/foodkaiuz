import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // For HapticFeedback
import '../../core/theme/app_theme.dart';
import 'package:provider/provider.dart';
import '../../logic/notifiers/user_notifier.dart';

class EditHealthDataScreen extends StatefulWidget {
  const EditHealthDataScreen({super.key});

  @override
  State<EditHealthDataScreen> createState() => _EditHealthDataScreenState();
}

class _EditHealthDataScreenState extends State<EditHealthDataScreen> {
  final _formKey = GlobalKey<FormState>();

  // Controllers
  final TextEditingController _weightController = TextEditingController(
    text: '70.0',
  );
  final TextEditingController _heightController = TextEditingController(
    text: '175',
  );
  final TextEditingController _ageController = TextEditingController(
    text: '25',
  );

  String _selectedActivity = 'Sedentary';
  String _selectedGender = 'Male';
  String _selectedGoal = 'Lose Weight';

  final List<String> _activities = [
    'Sedentary',
    'Lightly Active',
    'Moderately Active',
    'Very Active',
  ];

  final List<String> _genders = ['Male', 'Female'];
  final List<String> _goals = ['Lose Weight', 'Maintain Weight', 'Gain Muscle'];

  // Computed BMI
  double get _bmi {
    final weight = double.tryParse(_weightController.text) ?? 0;
    final height = double.tryParse(_heightController.text) ?? 0;
    if (weight <= 0 || height <= 0) return 0;
    return weight / ((height / 100) * (height / 100));
  }

  @override
  void initState() {
    super.initState();
    // Default values
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final userNotifier = Provider.of<UserNotifier>(context, listen: false);
      setState(() {
        _selectedActivity = userNotifier.user?.activityLevel ?? 'Sedentary';
        _selectedGender = userNotifier.user?.gender ?? 'Male';
        _selectedGoal = userNotifier.user?.goal ?? 'Lose Weight';
        _weightController.text = (userNotifier.user?.weight ?? 70.0).toString();
        _heightController.text = (userNotifier.user?.height ?? 175.0)
            .toString();
        _ageController.text = (userNotifier.user?.age ?? 25).toString();
      });
    });

    // Listen to changes for dynamic BMI updates
    _weightController.addListener(() => setState(() {}));
    _heightController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _weightController.dispose();
    _heightController.dispose();
    _ageController.dispose();
    super.dispose();
  }

  // VALIDATORS
  String? _validateWeight(String? value) {
    if (value == null || value.isEmpty) return 'Required';
    final n = double.tryParse(value);
    if (n == null || n < 30 || n > 300) {
      if (n == null || n < 0) HapticFeedback.vibrate();
      return 'Range: 30 - 300 kg';
    }
    return null;
  }

  String? _validateHeight(String? value) {
    if (value == null || value.isEmpty) return 'Required';
    final n = double.tryParse(value);
    if (n == null || n < 100 || n > 250) {
      if (n == null || n < 0) HapticFeedback.vibrate();
      return 'Range: 100 - 250 cm';
    }
    return null;
  }

  String? _validateAge(String? value) {
    if (value == null || value.isEmpty) return 'Required';
    final n = int.tryParse(value);
    if (n == null || n < 12 || n > 100) {
      if (n == null || n < 0) HapticFeedback.vibrate();
      return 'Range: 12 - 100 years';
    }
    return null;
  }

  void _save() {
    if (_formKey.currentState!.validate()) {
      // Safety Logic
      if (_bmi < 18.5 && _selectedGoal == 'Lose Weight') {
        HapticFeedback.mediumImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('BMI Low. "Maintain" or "Gain" recommended.'),
            backgroundColor: Colors.orange,
          ),
        );
        return;
      }

      // Save to Notifier
      context.read<UserNotifier>().updateUserData(
        activityLevel: _selectedActivity,
        gender: _selectedGender,
        weight: double.parse(_weightController.text),
        height: double.parse(_heightController.text),
        age: int.parse(_ageController.text),
        goal: _selectedGoal,
      );
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Changes Saved Successfully!')),
      );
    } else {
      HapticFeedback.heavyImpact();
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isLowBMI = _bmi > 0 && _bmi < 18.5;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Edit Health Data',
          style: Theme.of(
            context,
          ).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios,
            color: Theme.of(context).iconTheme.color,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _buildInputCard(
                'Weight (kg)',
                Icons.monitor_weight_outlined,
                controller: _weightController,
                suffix: 'kg',
                validator: _validateWeight,
              ),
              const SizedBox(height: 16),
              _buildInputCard(
                'Height (cm)',
                Icons.height,
                controller: _heightController,
                suffix: 'cm',
                validator: _validateHeight,
              ),
              const SizedBox(height: 16),
              _buildInputCard(
                'Age',
                Icons.cake_outlined,
                controller: _ageController,
                suffix: 'years',
                validator: _validateAge,
              ),
              const SizedBox(height: 16),

              // BMI Indicator (Optional helper)
              if (_bmi > 0)
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: isLowBMI
                        ? Colors.orange.withOpacity(0.1)
                        : Colors.green.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isLowBMI ? Colors.orange : Colors.green,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.info,
                        color: isLowBMI ? Colors.orange : Colors.green,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          isLowBMI
                              ? "Low BMI (${_bmi.toStringAsFixed(1)}). Consider 'Maintain' or 'Gain'."
                              : "BMI: ${_bmi.toStringAsFixed(1)} (Normal/High)",
                          style: TextStyle(
                            color: isLowBMI
                                ? Colors.orange[800]
                                : Colors.green[800],
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              _buildDropdownCard(
                'Gender',
                _getGenderIcon,
                _selectedGender,
                _genders,
                (val) => setState(() => _selectedGender = val!),
              ),
              const SizedBox(height: 16),

              _buildDropdownCard(
                'Activity Level',
                _getActivityIcon,
                _selectedActivity,
                _activities,
                (val) => setState(() => _selectedActivity = val!),
              ),
              const SizedBox(height: 16),

              _buildDropdownCard(
                'Main Goal',
                _getGoalIcon,
                _selectedGoal,
                _goals,
                (val) => setState(() {
                  if (isLowBMI && val == 'Lose Weight') {
                    HapticFeedback.selectionClick();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("Not recommended for your BMI"),
                      ),
                    );
                  }
                  _selectedGoal = val!;
                }),
              ),

              const SizedBox(height: 40),

              // Save Button
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _save,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.softMint,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: const Text(
                    'Save Changes',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInputCard(
    String label,
    IconData icon, {
    String? suffix,
    TextEditingController? controller,
    String? Function(String?)? validator,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: AppTheme.softShadow,
      ),
      child: TextFormField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Theme.of(context).textTheme.bodyLarge?.color,
          fontFamily: 'Poppins',
        ),
        validator: validator,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        decoration: InputDecoration(
          border: InputBorder.none,
          icon: Icon(icon, color: AppTheme.softMint),
          labelText: label,
          labelStyle: const TextStyle(color: AppTheme.subText, fontSize: 14),
          suffixText: suffix,
          suffixStyle: const TextStyle(
            color: AppTheme.subText,
            fontWeight: FontWeight.bold,
          ),
          errorStyle: const TextStyle(
            color: Colors.red,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  IconData _getGoalIcon(String goal) {
    if (goal.contains('Lose')) return Icons.trending_down;
    if (goal.contains('Muscle')) return Icons.fitness_center;
    return Icons.balance;
  }

  IconData _getActivityIcon(String activity) {
    if (activity.contains('Sedentary')) return Icons.chair;
    if (activity.contains('Lightly')) return Icons.directions_walk;
    if (activity.contains('Moderately')) return Icons.directions_run;
    if (activity.contains('Very')) return Icons.directions_bike;
    return Icons.directions_run;
  }

  IconData _getGenderIcon(String gender) {
    return gender == 'Male' ? Icons.male : Icons.female;
  }

  Widget _buildDropdownCard(
    String label,
    IconData Function(String) iconProvider,
    String value,
    List<String> items,
    ValueChanged<String?> onChanged,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: AppTheme.softShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 8, bottom: 4),
            child: Text(
              label,
              style: const TextStyle(color: AppTheme.subText, fontSize: 12),
            ),
          ),
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              dropdownColor: Theme.of(context).cardColor,
              icon: const Icon(Icons.arrow_drop_down, color: AppTheme.subText),
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).textTheme.bodyLarge?.color,
                fontFamily: 'Poppins',
              ),
              items: items.map((String item) {
                return DropdownMenuItem<String>(
                  value: item,
                  child: Row(
                    children: [
                      Icon(
                        iconProvider(item),
                        color: AppTheme.softMint,
                        size: 24,
                      ),
                      const SizedBox(width: 12),
                      Text(item),
                    ],
                  ),
                );
              }).toList(),
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }
}
