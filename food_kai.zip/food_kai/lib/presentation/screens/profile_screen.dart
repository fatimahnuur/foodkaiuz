import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../logic/notifiers/theme_notifier.dart';
import '../../core/theme/app_theme.dart';
import 'edit_health_data_screen.dart';
import 'nutrition_daily_screen.dart';
import 'nutrition_stats_screen.dart';
import 'package:provider/provider.dart';
import '../../logic/notifiers/user_notifier.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header Section
            Container(
              padding: const EdgeInsets.fromLTRB(24, 60, 24, 30),
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor, // softMint
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(32),
                  bottomRight: Radius.circular(32),
                ),
              ),
              width: double.infinity,
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  Consumer<UserNotifier>(
                    builder: (context, notifier, child) {
                      return Column(
                        children: [
                          CircleAvatar(
                            radius: 50,
                            backgroundColor: Colors.white.withOpacity(0.2),
                            backgroundImage: const AssetImage(
                              'assets/images/account.png',
                            ),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            notifier.user?.name ?? 'Guest User',
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Activity: ${notifier.user?.activityLevel ?? "Unknown"}',
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),

            // Menu Section
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  _buildMenuCard(context, 'Health Details', Icons.favorite, [
                    _buildMenuItem(
                      context,
                      'Edit Health Data',
                      Icons.edit,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const EditHealthDataScreen(),
                          ),
                        );
                      },
                    ),
                    _buildMenuItem(
                      context,
                      'Daily Nutrition',
                      Icons.pie_chart,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const NutritionDailyScreen(),
                          ),
                        );
                      },
                    ),
                    _buildMenuItem(
                      context,
                      'Weekly/Monthly Stats',
                      Icons.bar_chart,
                      onTap: () {
                        Navigator.push(
                          context,
                          CupertinoPageRoute(
                            builder: (context) =>
                                const NutritionStatsScreen(period: 'Week'),
                          ),
                        );
                      },
                    ),
                  ]),
                  const SizedBox(height: 24),
                  _buildMenuCard(context, 'Settings', Icons.settings, [
                    _buildMenuItem(
                      context,
                      'Language',
                      Icons.language,
                      trailing: const Text(
                        'English',
                        style: TextStyle(
                          color: AppTheme.subText,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Consumer<ThemeNotifier>(
                      builder: (context, notifier, _) {
                        return _buildMenuItem(
                          context,
                          'Dark Mode',
                          Icons.dark_mode,
                          trailing: Switch(
                            value: notifier.isDarkMode,
                            onChanged: (val) => notifier.toggleTheme(),
                            activeColor: AppTheme.softMint,
                          ),
                        );
                      },
                    ),
                    _buildMenuItem(
                      context,
                      'Delete History',
                      Icons.cleaning_services,
                      isDestructive: true,
                      onTap: () {
                        // For MVP, just clearing Today's logs or show functionality not available
                        // Since there's no "Delete All History" in UserNotifier yet, let's just clear today's logs for demo
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('History cleared for today (Demo)'),
                          ),
                        );
                      },
                    ),
                    _buildMenuItem(
                      context,
                      'Log Out',
                      Icons.logout,
                      isDestructive: true,
                      onTap: () {
                        context.read<UserNotifier>().logout(context);
                      },
                    ),
                    _buildMenuItem(
                      context,
                      'Delete Account',
                      Icons.delete,
                      isDestructive: true,
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: const Text('Delete Account?'),
                            content: const Text(
                              'This action is permanent. All your health data and history will be lost.',
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context),
                                child: const Text('Cancel'),
                              ),
                              TextButton(
                                onPressed: () {
                                  Navigator.pop(context); // Close dialog
                                  context.read<UserNotifier>().deleteAccount(
                                    context,
                                  );
                                },
                                style: TextButton.styleFrom(
                                  foregroundColor: Colors.red,
                                ),
                                child: const Text('Delete'),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ]),
                ],
              ),
            ),
            const SizedBox(height: 120),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuCard(
    BuildContext context,
    String title,
    IconData icon,
    List<Widget> children,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(24),
        boxShadow: AppTheme.softShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppTheme.softMint),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  color: AppTheme.subText,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const Divider(height: 24),
          ...children,
        ],
      ),
    );
  }

  Widget _buildMenuItem(
    BuildContext context,
    String title,
    IconData icon, {
    Widget? trailing,
    bool isDestructive = false,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: isDestructive
                    ? AppTheme.lightCoral.withOpacity(0.2)
                    : Theme.of(context).scaffoldBackgroundColor, // Use theme bg
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: isDestructive ? Colors.red : AppTheme.softMint,
                size: 20,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: isDestructive
                      ? Colors.red
                      : Theme.of(context).textTheme.bodyLarge?.color,
                ),
              ),
            ),
            if (trailing != null) trailing,
            if (trailing == null)
              Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: Colors.grey.withOpacity(0.5),
              ),
          ],
        ),
      ),
    );
  }
}
