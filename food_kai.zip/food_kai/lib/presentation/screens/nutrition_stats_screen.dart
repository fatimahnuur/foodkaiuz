import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

class NutritionStatsScreen extends StatelessWidget {
  final String period; // 'Weekly' or 'Monthly'

  const NutritionStatsScreen({super.key, required this.period});

  @override
  Widget build(BuildContext context) {
    final isWeekly = period == 'Weekly';
    // Mock Data
    final values = isWeekly
        ? [1800, 2100, 1950, 2400, 1600, 2000, 2200]
        : [
            2000,
            1800,
            2200,
            1900,
            2100,
            2300,
            2000,
            1800,
            2200,
            2100,
          ]; // Just a sample

    final labels = isWeekly
        ? ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        : ['W1', 'W2', 'W3', 'W4', 'W1', 'W2', 'W3', 'W4', 'W1', 'W2'];

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          '$period Overview',
          style: Theme.of(
            context,
          ).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Theme.of(context).iconTheme.color),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Chart Card
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(24),
                boxShadow: AppTheme.softShadow,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Calorie Intake',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).textTheme.bodyLarge?.color,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Custom Bar Chart
                  SizedBox(
                    height: 200,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: List.generate(values.length, (index) {
                        final heightFactor = (values[index] / 3000).clamp(
                          0.0,
                          1.0,
                        );
                        return Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                              width: isWeekly ? 20 : 12,
                              height: 200 * heightFactor,
                              decoration: BoxDecoration(
                                color: AppTheme.softMint,
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              labels[index],
                              style: const TextStyle(
                                color: AppTheme.subText,
                                fontSize: 10,
                              ),
                            ),
                          ],
                        );
                      }),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Stats List
            _buildStatRow(
              context,
              'Average Calories',
              isWeekly ? '2,015 kcal' : '2,050 kcal',
              Icons.bar_chart,
            ),
            _buildStatRow(
              context,
              'Highest Day',
              isWeekly ? 'Thu (2,400)' : 'Week 2 (2,300)',
              Icons.arrow_upward,
            ),
            _buildStatRow(
              context,
              'Lowest Day',
              isWeekly ? 'Fri (1,600)' : 'Week 3 (1,800)',
              Icons.arrow_downward,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatRow(
    BuildContext context,
    String label,
    String value,
    IconData icon,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: AppTheme.softShadow,
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Theme.of(context).scaffoldBackgroundColor,
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: Theme.of(context).iconTheme.color,
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Theme.of(context).textTheme.bodyLarge?.color,
            ),
          ),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: AppTheme.softMint,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }
}
