import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:food_kai/logic/notifiers/user_notifier.dart';
import 'package:food_kai/logic/notifiers/theme_notifier.dart';
import 'recommendation_screen.dart';
import 'notification_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '',
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(color: AppTheme.subText),
            ),
            Row(
              children: [
                const CircleAvatar(
                  radius: 20,
                  backgroundImage: AssetImage(
                    'assets/images/account.png',
                  ), // Placeholder or use network image
                ),
                const SizedBox(width: 12),
                Consumer<UserNotifier>(
                  builder: (context, notifier, child) {
                    return Text(
                      notifier.user?.name ?? 'Guest',
                      style: Theme.of(context).textTheme.headlineSmall
                          ?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).textTheme.bodyLarge?.color,
                            fontSize: 20,
                          ),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
        actions: [
          Consumer<UserNotifier>(
            builder: (context, notifier, child) {
              return Stack(
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        CupertinoPageRoute(
                          builder: (context) => const NotificationScreen(),
                        ),
                      );
                    },
                    icon: Icon(
                      Icons.notifications_outlined,
                      color: Theme.of(context).iconTheme.color,
                      size: 28,
                    ),
                  ),
                  if (notifier.hasUnreadNotifications)
                    Positioned(
                      right: 12,
                      top: 12,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          Consumer<ThemeNotifier>(
            builder: (context, notifier, child) {
              return Switch(
                value: notifier.isDarkMode,
                onChanged: (val) => notifier.toggleTheme(),
                activeColor: AppTheme.softMint,
              );
            },
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 12),
            // Activity Level Selector
            SizedBox(
              height: 50,
              child: Consumer<UserNotifier>(
                builder: (context, notifier, child) {
                  final levels = [
                    'Sedentary',
                    'Lightly Active',
                    'Moderately Active',
                    'Very Active',
                  ];
                  return ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    itemCount: levels.length,
                    itemBuilder: (context, index) {
                      final level = levels[index];
                      final isSelected =
                          (notifier.user?.activityLevel ?? 'Sedentary') ==
                          level;

                      IconData icon;
                      if (level.contains('Sedentary'))
                        icon = Icons.chair;
                      else if (level.contains('Lightly'))
                        icon = Icons.directions_walk;
                      else if (level.contains('Moderately'))
                        icon = Icons.directions_run;
                      else
                        icon = Icons.directions_bike;

                      return GestureDetector(
                        onTap: () => notifier.setActivityLevel(level),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          margin: const EdgeInsets.only(right: 12),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? AppTheme.softMint
                                : Theme.of(context).cardColor,
                            borderRadius: BorderRadius.circular(24),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: AppTheme.softMint.withOpacity(0.4),
                                      blurRadius: 8,
                                      offset: const Offset(0, 4),
                                    ),
                                  ]
                                : [],
                            border: Border.all(
                              color: isSelected
                                  ? Colors.transparent
                                  : Colors.grey[300]!,
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                icon,
                                color: isSelected
                                    ? Colors.white
                                    : AppTheme.subText,
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                level,
                                style: TextStyle(
                                  color: isSelected
                                      ? Colors.white
                                      : AppTheme.subText,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 16),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                // Main content column wrapper
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Calorie Card
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: AppTheme.softShadow,
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Calories Remaining',
                              style: Theme.of(context).textTheme.bodyMedium
                                  ?.copyWith(color: AppTheme.subText),
                            ),
                            Consumer<UserNotifier>(
                              builder: (context, notifier, child) {
                                return Text(
                                  'Target: ${notifier.user?.dailyCalorieGoal ?? 2000}',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              '1433',
                              style: Theme.of(context).textTheme.displayMedium
                                  ?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: AppTheme.softMint,
                                    height: 1.0,
                                  ),
                            ),
                            const SizedBox(width: 8),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 8.0),
                              child: Text(
                                'kcal',
                                style: TextStyle(
                                  color: AppTheme.subText,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        LinearProgressIndicator(
                          value: 0.6,
                          backgroundColor: const Color(0xFFF1F2F6),
                          color: AppTheme.softMint,
                          minHeight: 12,
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Macros Grid
                  Row(
                    children: [
                      _buildMacroCard(
                        context,
                        'Protein',
                        '140g',
                        Colors.blueAccent,
                        'assets/icons/meat.png',
                      ),
                      const SizedBox(width: 16),
                      _buildMacroCard(
                        context,
                        'Carbs',
                        '220g',
                        Colors.amber,
                        'assets/icons/wheat.png',
                      ),
                      const SizedBox(width: 16),
                      _buildMacroCard(
                        context,
                        'Fats',
                        '70g',
                        Colors.redAccent,
                        'assets/icons/oil.png',
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),

                  // AI Suggestion Banner
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE8F5E9),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          CupertinoPageRoute(
                            builder: (context) => const RecommendationScreen(),
                          ),
                        );
                      },
                      child: Row(
                        children: [
                          const Icon(Icons.auto_awesome, color: Colors.green),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Text(
                              'Sizda bugun Protein biroz kam. KAI sizga yogurtni maslahat beradi!',
                              style: TextStyle(
                                color: Colors.green[900],
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          const Icon(
                            Icons.arrow_forward_ios,
                            size: 16,
                            color: Colors.green,
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),
                  Text(
                    "Yaqinda iste'mol qilindi",
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildRecentItem(
                    context,
                    'Baqlajon salat',
                    '147 kcal',
                    Colors.green,
                  ),
                ],
              ),
            ),
          ],
        ),
        padding: const EdgeInsets.only(bottom: 120),
      ),
    );
  }

  Widget _buildMacroCard(
    BuildContext context,
    String title,
    String value,
    Color color,
    String iconPath,
  ) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(20),
          boxShadow: AppTheme.softShadow,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Align(
              alignment: Alignment.center, // Center the icon
              child: Image.asset(iconPath, height: 32, width: 32),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(color: AppTheme.subText),
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).textTheme.bodyLarge?.color,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              height: 4,
              width: 40,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentItem(
    BuildContext context,
    String name,
    String calories,
    Color iconColor,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: AppTheme.softShadow,
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFF1F2F6),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.bar_chart, color: iconColor),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              name,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
                color: Theme.of(context).textTheme.bodyLarge?.color,
              ),
            ),
          ),
          Text(
            calories,
            style: TextStyle(color: iconColor, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
