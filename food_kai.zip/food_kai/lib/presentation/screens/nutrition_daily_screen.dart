import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../logic/notifiers/user_notifier.dart';

class NutritionDailyScreen extends StatefulWidget {
  const NutritionDailyScreen({super.key});

  @override
  State<NutritionDailyScreen> createState() => _NutritionDailyScreenState();
}

class _NutritionDailyScreenState extends State<NutritionDailyScreen> {
  @override
  void initState() {
    super.initState();
    // Fetch logs on init
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<UserNotifier>().fetchTodayLogs();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Daily Summary',
          style: Theme.of(
            context,
          ).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Theme.of(context).iconTheme.color),
        centerTitle: true,
      ),
      body: Consumer<UserNotifier>(
        builder: (context, notifier, child) {
          final logs = notifier.todayLogs;
          final target = notifier.user?.dailyCalorieGoal ?? 2000;

          double consumed = 0;
          double protein = 0;
          double carbs = 0;
          double fat = 0;

          for (var item in logs) {
            consumed += item.totalCalories;
            protein += item.totalProtein;
            carbs += item.totalCarbs;
            fat += item.totalFat;
          }

          final progress = (consumed / target).clamp(0.0, 1.0);

          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Donut Chart - Calories
                Container(
                  padding: const EdgeInsets.all(32),
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: AppTheme.softShadow,
                  ),
                  child: Column(
                    children: [
                      Stack(
                        alignment: Alignment.center,
                        children: [
                          SizedBox(
                            height: 180,
                            width: 180,
                            child: CircularProgressIndicator(
                              value: progress,
                              strokeWidth: 16,
                              backgroundColor: Colors.grey[100],
                              valueColor: const AlwaysStoppedAnimation<Color>(
                                AppTheme.softMint,
                              ),
                              strokeCap: StrokeCap.round,
                            ),
                          ),
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.local_fire_department,
                                color: Colors.orange,
                                size: 32,
                              ),
                              Text(
                                consumed.toStringAsFixed(0),
                                style: TextStyle(
                                  fontSize: 32,
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(
                                    context,
                                  ).textTheme.bodyLarge?.color,
                                ),
                              ),
                              Text(
                                'of $target kcal',
                                style: TextStyle(
                                  color: AppTheme.subText,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),
                      Text(
                        consumed < target
                            ? 'You have ${target - consumed.toInt()} kcal left!'
                            : 'You hit your goal! Great job!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Theme.of(context).textTheme.bodyLarge?.color,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // Macros
                Row(
                  children: [
                    _buildMacroCard(
                      context,
                      'Carbs',
                      '${carbs.toStringAsFixed(0)}g',
                      0.6,
                      Colors.blue,
                    ),
                    const SizedBox(width: 16),
                    _buildMacroCard(
                      context,
                      'Protein',
                      '${protein.toStringAsFixed(0)}g',
                      0.8,
                      Colors.green,
                    ),
                    const SizedBox(width: 16),
                    _buildMacroCard(
                      context,
                      'Fat',
                      '${fat.toStringAsFixed(0)}g',
                      0.4,
                      Colors.orange,
                    ),
                  ],
                ),

                const SizedBox(height: 32),

                // History List Header
                Text(
                  "Today's History",
                  style: Theme.of(
                    context,
                  ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),

                // List
                if (logs.isEmpty)
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Text(
                        "No meals logged yet today.",
                        style: TextStyle(color: AppTheme.subText),
                      ),
                    ),
                  )
                else
                  ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: logs.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final item = logs[index];
                      return Dismissible(
                        key: UniqueKey(), // Simplest unique key for demo
                        direction: DismissDirection.endToStart,
                        onDismissed: (_) {
                          notifier.deleteFoodLog(index, item);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Item deleted')),
                          );
                        },
                        background: Container(
                          padding: const EdgeInsets.only(right: 20),
                          alignment: Alignment.centerRight,
                          decoration: BoxDecoration(
                            color: Colors.redAccent,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Icon(Icons.delete, color: Colors.white),
                        ),
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Theme.of(context).cardColor,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: AppTheme.softShadow,
                          ),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: AppTheme.softMint.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Icon(
                                  Icons.restaurant,
                                  color: AppTheme.softMint,
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item.name,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        color: Theme.of(
                                          context,
                                        ).textTheme.bodyLarge?.color,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Text(
                                '${item.totalCalories.toStringAsFixed(0)} kcal',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(
                                    context,
                                  ).textTheme.bodyLarge?.color,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                const SizedBox(height: 40),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildMacroCard(
    BuildContext context,
    String label,
    String value,
    double progress,
    Color color,
  ) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(20),
          boxShadow: AppTheme.softShadow,
        ),
        child: Column(
          children: [
            Text(
              label,
              style: const TextStyle(color: AppTheme.subText, fontSize: 12),
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Theme.of(context).textTheme.bodyLarge?.color,
              ),
            ),
            const SizedBox(height: 12),
            LinearProgressIndicator(
              value: progress,
              backgroundColor: color.withOpacity(0.1),
              color: color,
              minHeight: 6,
              borderRadius: BorderRadius.circular(4),
            ),
          ],
        ),
      ),
    );
  }
}
