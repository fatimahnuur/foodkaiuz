import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../logic/notifiers/meal_notifier.dart';
import '../widgets/recommendation_tile.dart';

class RecommendationScreen extends StatelessWidget {
  const RecommendationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Meal Suggestion',
          style: Theme.of(
            context,
          ).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Theme.of(context).primaryColor, // softMint
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Column(
        children: [
          // 1. Aesthetic Header (Replaced by AppBar and a new custom header for the AI message)
          Container(
            padding: const EdgeInsets.fromLTRB(
              24,
              20,
              24,
              30,
            ), // Adjusted padding
            decoration: BoxDecoration(
              // Changed to BoxDecoration to allow for gradient/shadow if needed
              color: Theme.of(
                context,
              ).primaryColor, // Use primaryColor for consistency
              borderRadius: const BorderRadius.vertical(
                bottom: Radius.circular(32),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(
                            Icons.auto_awesome,
                            color: Colors.white,
                            size: 28,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Gemini AI',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.9),
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              letterSpacing: 1.0,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Hi! Based on your 500 kcal limit...',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          height: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
                // Close button (Removed as AppBar handles navigation back)
              ],
            ),
          ),

          // 2. Interactive Goal Chips
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
            child: Consumer<MealNotifier>(
              builder: (context, notifier, child) {
                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: notifier.categories.map((category) {
                      final isSelected =
                          notifier.selectedCategory ==
                          category; // Keep original logic for category selection
                      return Padding(
                        padding: const EdgeInsets.only(right: 12),
                        child: ChoiceChip(
                          label: Text(category),
                          selected: isSelected,
                          onSelected: (_) => notifier.selectCategory(category),
                          selectedColor: AppTheme
                              .softMint, // Keep AppTheme.softMint for selected color
                          backgroundColor: Theme.of(
                            context,
                          ).cardColor, // Use Theme.of(context).cardColor
                          labelStyle: TextStyle(
                            color: isSelected
                                ? Colors.white
                                : Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.color, // Use Theme.of(context).textTheme.bodyMedium?.color for unselected
                            fontWeight: FontWeight.bold,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                            side: BorderSide(
                              color: isSelected
                                  ? Colors.transparent
                                  : Colors.grey[200]!,
                            ),
                          ),
                          showCheckmark: false,
                        ),
                      );
                    }).toList(),
                  ),
                );
              },
            ),
          ),

          // 3. Recommendation List
          Expanded(
            child: Consumer<MealNotifier>(
              builder: (context, notifier, child) {
                if (notifier.isLoading) {
                  return Center(
                    child: CircularProgressIndicator(color: AppTheme.softMint),
                  );
                }

                if (notifier.recommendations.isEmpty) {
                  return const Center(child: Text("No meals found."));
                }

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  itemCount: notifier.recommendations.length,
                  itemBuilder: (context, index) {
                    final meal = notifier.recommendations[index];
                    return RecommendationTile(meal: meal);
                  },
                );
              },
            ),
          ),

          // 4. Regenerate Button
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: SafeArea(
              child: Consumer<MealNotifier>(
                builder: (context, notifier, child) {
                  return InkWell(
                    onTap: notifier.regenerate,
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      height: 56,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF81D4C2), Color(0xFFB2EBF2)],
                        ),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF81D4C2).withOpacity(0.4),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Center(
                        child: notifier.isLoading
                            ? const SizedBox(
                                height: 24,
                                width: 24,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              )
                            : const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.refresh, color: Colors.white),
                                  SizedBox(width: 8),
                                  Text(
                                    'Regenerate Plan',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
