import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/food_item.dart';

enum DataMode { cloud, local }

class FoodNotifier extends ChangeNotifier {
  FoodItem? _scannedFood;
  DataMode _dataMode = DataMode.local;

  List<dynamic> _foodDatabase = [];
  bool _isResourcesLoaded = false;

  FoodItem? get scannedFood => _scannedFood;
  DataMode get dataMode => _dataMode;

  FoodNotifier() {
    _loadResources();
  }

  Future<void> _loadResources() async {
    try {
      // Load Database
      final dbString = await rootBundle.loadString('assets/food_database.json');
      _foodDatabase = json.decode(dbString);
      debugPrint('Database Loaded: ${_foodDatabase.length} items');

      _isResourcesLoaded = true;
    } catch (e) {
      debugPrint('Error loading resources: $e');
    }
  }

  void setMode(DataMode mode) {
    _dataMode = mode;
    notifyListeners();
  }

  void setScannedFood(FoodItem food) {
    _scannedFood = food;
    notifyListeners();
  }

  void updateIngredientWeight(int index, double newWeight) {
    if (_scannedFood != null &&
        index >= 0 &&
        index < _scannedFood!.ingredients.length) {
      _scannedFood!.ingredients[index].weightGrams = newWeight;
      notifyListeners();
    }
  }

  void lookupFood(String label) {
    if (!_isResourcesLoaded) return;

    debugPrint('Looking up: $label');

    // Find item with partial match or exact match
    final foodData = _foodDatabase.firstWhere(
      (item) =>
          item['name'].toString().toLowerCase().contains(label.toLowerCase()),
      orElse: () => null,
    );

    if (foodData != null) {
      List<Ingredient> ingredients = [];
      if (foodData['ingredients'] != null) {
        for (var i in foodData['ingredients']) {
          ingredients.add(
            Ingredient(
              name: i['item'],
              weightGrams: 100,
              caloriesPer100g: (i['kcal'] as num).toDouble(),
              proteinPer100g: 5.0, // Mock
              fatPer100g: 5.0, // Mock
              carbsPer100g: 10.0, // Mock
            ),
          );
        }
      }

      _scannedFood = FoodItem(name: foodData['name'], ingredients: ingredients);
      notifyListeners();
    } else {
      // Fallback
      debugPrint('Label $label not found in DB');
      _scannedFood = FoodItem(
        name: '$label (No Nutrition Info)',
        ingredients: [],
      );
      notifyListeners();
    }
  }

  Future<void> simulateScan() async {
    // Keep existing mock for fallback
    await Future.delayed(const Duration(seconds: 2));
    _scannedFood = FoodItem(name: 'Mock Item', ingredients: []);
    notifyListeners();
  }
}
