import 'package:flutter/material.dart';

class Meal {
  final String id;
  final String name;
  final int calories;
  final String imageUrl; // Placeholder for now
  final List<String> tags; // e.g., 'Low Fat', 'High Protein'
  final String category; // 'Weight Loss', 'High Protein', 'Uzbek Cuisine'

  Meal({
    required this.id,
    required this.name,
    required this.calories,
    required this.imageUrl,
    required this.tags,
    required this.category,
  });
}

class MealNotifier extends ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String _selectedCategory = 'Weight Loss';
  String get selectedCategory => _selectedCategory;

  final List<String> _categories = [
    'Weight Loss',
    'High Protein',
    'Uzbek Cuisine',
  ];
  List<String> get categories => _categories;

  List<Meal> _allMeals = [
    Meal(
      id: '1',
      name: 'Grilled Chicken Salad',
      calories: 350,
      imageUrl: 'assets/images/salad.png', // Mock
      tags: ['High Protein', 'Low Carb'],
      category: 'Weight Loss',
    ),
    Meal(
      id: '2',
      name: 'Oatmeal with Berries',
      calories: 280,
      imageUrl: 'assets/images/oatmeal.png', // Mock
      tags: ['High Fiber', 'Vegan'],
      category: 'Weight Loss',
    ),
    Meal(
      id: '3',
      name: 'Steak & Asparagus',
      calories: 500,
      imageUrl: 'assets/images/steak.png', // Mock
      tags: ['High Protein', 'Keto'],
      category: 'High Protein',
    ),
    Meal(
      id: '4',
      name: 'Protein Yogurt Parfait',
      calories: 320,
      imageUrl: 'assets/images/yogurt.png', // Mock
      tags: ['Probiotic', 'Calcium'],
      category: 'High Protein',
    ),
    Meal(
      id: '5',
      name: 'Plov (Lite Version)',
      calories: 600,
      imageUrl: 'assets/images/plov.png', // Mock
      tags: ['Traditional', 'Savory'],
      category: 'Uzbek Cuisine',
    ),
    Meal(
      id: '6',
      name: 'Mastava Soup',
      calories: 400,
      imageUrl: 'assets/images/mastava.png', // Mock
      tags: ['Warm', 'Nutritious'],
      category: 'Uzbek Cuisine',
    ),
  ];

  List<Meal> get recommendations =>
      _allMeals.where((m) => m.category == _selectedCategory).toList();

  void selectCategory(String category) {
    if (_selectedCategory == category) return;
    _selectedCategory = category;
    notifyListeners();
  }

  Future<void> regenerate() async {
    _isLoading = true;
    notifyListeners();
    // Simulate API call
    await Future.delayed(const Duration(seconds: 2));
    _isLoading = false;
    notifyListeners();
  }
}
