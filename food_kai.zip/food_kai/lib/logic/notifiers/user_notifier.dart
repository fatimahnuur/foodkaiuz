import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../models/food_item.dart';

class NotificationModel {
  final String title;
  final String message;
  final String timeAgo;
  final IconData icon;
  final Color color;
  bool isRead;

  NotificationModel({
    required this.title,
    required this.message,
    required this.timeAgo,
    required this.icon,
    required this.color,
    this.isRead = false,
  });
}

class UserNotifier extends ChangeNotifier {
  UserModel? _user;
  bool _isLoading = false;

  UserModel? get user => _user;
  bool get isLoading => _isLoading;

  // Local fallback if Firebase not init
  bool _useLocal = true;

  // Notifications
  List<NotificationModel> _notifications = [
    NotificationModel(
      title: 'Time for lunch!',
      message: 'Don\'t forget to track your meal.',
      timeAgo: '2 mins ago',
      icon: Icons.lunch_dining,
      color: Colors.orange,
    ),
  ];

  List<NotificationModel> get notifications => _notifications;
  bool get hasUnreadNotifications => _notifications.any((n) => !n.isRead);

  UserNotifier() {
    // Initialize with default local user for immediate UI
    _user = UserModel(
      uid: 'local',
      name: 'Guest',
      email: '',
      gender: 'Male',
      age: 25,
      weight: 70.0,
      height: 175.0,
      activityLevel: 'Sedentary',
      goal: 'Lose Weight',
      dailyCalorieGoal: 2000,
    );
  }

  // Init Listener
  void initUserListener() {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser != null) {
        _useLocal = false;
        FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser.uid)
            .snapshots()
            .listen((snapshot) {
              if (snapshot.exists && snapshot.data() != null) {
                _user = UserModel.fromMap(snapshot.data()!, currentUser.uid);
                notifyListeners();
              }
            });
      }
    } catch (e) {
      debugPrint("Firebase not ready or error: $e");
      _useLocal = true;
    }
  }

  // Update Data
  Future<void> updateUserData({
    String? name,
    String? email, // Added email
    String? gender,
    int? age,
    double? weight,
    double? height,
    String? activityLevel,
    String? goal,
  }) async {
    if (_user == null) return;

    // Calculate new metrics
    String newGender = gender ?? _user!.gender;
    double newWeight = weight ?? _user!.weight;
    double newHeight = height ?? _user!.height;
    int newAge = age ?? _user!.age;
    String newActivity = activityLevel ?? _user!.activityLevel;
    String newGoal = goal ?? _user!.goal;

    int newCalories = _calculateMifflinStJeor(
      newWeight,
      newHeight,
      newAge,
      newGender,
      newActivity,
      newGoal,
    );

    // Update Local immediately for UI responsiveness
    _user = _user!.copyWith(
      name: name,
      email: email ?? _user!.email, // Added email update
      gender: newGender,
      age: newAge,
      weight: newWeight,
      height: newHeight,
      activityLevel: newActivity,
      goal: newGoal,
      dailyCalorieGoal: newCalories,
    );
    notifyListeners();

    // Sync to Firestore if available
    if (!_useLocal) {
      try {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(_user!.uid)
            .update(_user!.toMap());
      } catch (e) {
        debugPrint("Error updating Firestore: $e");
      }
    }
  }

  int _calculateMifflinStJeor(
    double weight,
    double height,
    int age,
    String gender,
    String activity,
    String goal,
  ) {
    // 1. BMR Calculation
    double bmr;
    if (gender == 'Male') {
      bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5;
    } else {
      bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161;
    }

    // 2. Activity Multiplier
    double activityFactor;
    switch (activity) {
      case 'Sedentary':
        activityFactor = 1.2;
        break;
      case 'Lightly Active':
        activityFactor = 1.375;
        break;
      case 'Moderately Active':
        activityFactor = 1.55;
        break;
      case 'Very Active':
        activityFactor = 1.725;
        break;
      default:
        activityFactor = 1.2;
    }

    double tdee = bmr * activityFactor;

    // 3. Goal Adjustment
    double calories;
    if (goal == 'Lose Weight') {
      calories = tdee - 500;
    } else if (goal == 'Gain Muscle') {
      calories = tdee + 300;
    } else {
      calories = tdee;
    }

    // Safety Clamp: Minimum 1200 kcal
    return calories < 1200 ? 1200 : calories.round();
  }

  // Food Logging Logic
  List<FoodItem> _todayLogs = [];
  List<FoodItem> get todayLogs => _todayLogs;

  // Add a food item
  Future<void> logFood(FoodItem item) async {
    final newItem = FoodItem(
      name: item.name,
      ingredients: item.ingredients,
      timestamp: DateTime.now(),
    );

    _todayLogs.add(newItem);
    notifyListeners();

    if (!_useLocal) {
      if (_user?.uid == null) return;
      try {
        final dateStr = DateTime.now().toIso8601String().split('T')[0];
        await FirebaseFirestore.instance
            .collection('users')
            .doc(_user!.uid)
            .collection('logs')
            .doc(dateStr)
            .collection('items')
            .add(newItem.toMap());
      } catch (e) {
        debugPrint("Error logging food: $e");
      }
    }
  }

  // Delete a food item
  Future<void> deleteFoodLog(int index, FoodItem item) async {
    _todayLogs.removeAt(index);
    notifyListeners();

    if (!_useLocal && item.id != null) {
      if (_user?.uid == null) return;
      try {
        final dateStr = DateTime.now().toIso8601String().split('T')[0];
        await FirebaseFirestore.instance
            .collection('users')
            .doc(_user!.uid)
            .collection('logs')
            .doc(dateStr)
            .collection('items')
            .doc(item.id)
            .delete();
      } catch (e) {
        debugPrint("Error deleting food log: $e");
      }
    }
  }

  // Fetch today's logs (Call this on init or refresh)
  Future<void> fetchTodayLogs() async {
    if (_useLocal) return;
    if (_user?.uid == null) return;

    try {
      final dateStr = DateTime.now().toIso8601String().split('T')[0];
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(_user!.uid)
          .collection('logs')
          .doc(dateStr)
          .collection('items')
          .orderBy('timestamp', descending: true)
          .get();

      _todayLogs = snapshot.docs
          .map((doc) => FoodItem.fromMap(doc.data(), id: doc.id))
          .toList();
      notifyListeners();
    } catch (e) {
      debugPrint("Error fetching logs: $e");
    }
  }

  // Account Deletion
  Future<void> deleteAccount(BuildContext context) async {
    try {
      if (_user?.uid != null && !_useLocal) {
        // 1. Delete Firestore Data
        await FirebaseFirestore.instance
            .collection('users')
            .doc(_user!.uid)
            .delete();

        // Note: Subcollections (like 'logs') must be deleted manually or via Cloud Functions in a real app.
        // For this demo, we assume main user doc deletion is sufficient or handled by rules/functions.
      }

      // 2. Delete Auth User
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await user.delete();
      }

      // 3. Reset Local State
      _user = null;
      _todayLogs = [];
      notifyListeners();

      // 4. Navigate to Login
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
    } catch (e) {
      debugPrint("Error deleting account: $e");
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error deleting account: $e')));
    }
  }

  // Logout
  Future<void> logout(BuildContext context) async {
    try {
      await FirebaseAuth.instance.signOut();
      _user = null;
      _todayLogs = [];
      notifyListeners();
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
    } catch (e) {
      debugPrint("Error logging out: $e");
    }
  }

  // Deprecated setters wrappers for backward compatibility if needed,
  // but preferably use updateUserData
  void setActivityLevel(String level) => updateUserData(activityLevel: level);
  void setGender(String gender) => updateUserData(gender: gender);

  void markAllAsRead() {
    for (var n in _notifications) {
      n.isRead = true;
    }
    notifyListeners();
  }
}
