class Ingredient {
  final String name;
  double weightGrams;
  final double caloriesPer100g;
  final double proteinPer100g;
  final double fatPer100g;
  final double carbsPer100g;

  Ingredient({
    required this.name,
    required this.weightGrams,
    required this.caloriesPer100g,
    required this.proteinPer100g,
    required this.fatPer100g,
    required this.carbsPer100g,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'weightGrams': weightGrams,
      'caloriesPer100g': caloriesPer100g,
      'proteinPer100g': proteinPer100g,
      'fatPer100g': fatPer100g,
      'carbsPer100g': carbsPer100g,
    };
  }

  factory Ingredient.fromMap(Map<String, dynamic> map) {
    return Ingredient(
      name: map['name'] ?? '',
      weightGrams: (map['weightGrams'] ?? 0).toDouble(),
      caloriesPer100g: (map['caloriesPer100g'] ?? 0).toDouble(),
      proteinPer100g: (map['proteinPer100g'] ?? 0).toDouble(),
      fatPer100g: (map['fatPer100g'] ?? 0).toDouble(),
      carbsPer100g: (map['carbsPer100g'] ?? 0).toDouble(),
    );
  }

  double get totalCalories => (caloriesPer100g * weightGrams) / 100;
  double get totalProtein => (proteinPer100g * weightGrams) / 100;
  double get totalFat => (fatPer100g * weightGrams) / 100;
  double get totalCarbs => (carbsPer100g * weightGrams) / 100;
}

class FoodItem {
  final String name;
  final List<Ingredient> ingredients;
  final String? id; // For Firestore ID
  final DateTime? timestamp;

  FoodItem({
    required this.name,
    required this.ingredients,
    this.id,
    this.timestamp,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'ingredients': ingredients.map((x) => x.toMap()).toList(),
      'timestamp': timestamp?.millisecondsSinceEpoch,
    };
  }

  factory FoodItem.fromMap(Map<String, dynamic> map, {String? id}) {
    return FoodItem(
      id: id,
      name: map['name'] ?? '',
      timestamp: map['timestamp'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['timestamp'])
          : null,
      ingredients: List<Ingredient>.from(
        (map['ingredients'] as List<dynamic>? ?? []).map<Ingredient>(
          (x) => Ingredient.fromMap(x as Map<String, dynamic>),
        ),
      ),
    );
  }

  double get totalCalories =>
      ingredients.fold(0, (sum, item) => sum + item.totalCalories);
  double get totalProtein =>
      ingredients.fold(0, (sum, item) => sum + item.totalProtein);
  double get totalFat =>
      ingredients.fold(0, (sum, item) => sum + item.totalFat);
  double get totalCarbs =>
      ingredients.fold(0, (sum, item) => sum + item.totalCarbs);
}
