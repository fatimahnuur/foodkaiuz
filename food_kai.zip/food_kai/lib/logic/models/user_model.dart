class UserModel {
  final String uid;
  final String name;
  final String email;
  final String gender;
  final int age;
  final double weight;
  final double height;
  final String activityLevel;
  final String goal;
  final int dailyCalorieGoal;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.gender,
    required this.age,
    required this.weight,
    required this.height,
    required this.activityLevel,
    required this.goal,
    required this.dailyCalorieGoal,
  });

  // Calculate BMI
  double get bmi => weight / ((height / 100) * (height / 100));

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'email': email,
      'gender': gender,
      'age': age,
      'weight': weight,
      'height': height,
      'activityLevel': activityLevel,
      'goal': goal,
      'dailyCalorieGoal': dailyCalorieGoal,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map, String uid) {
    return UserModel(
      uid: uid,
      name: map['name'] ?? 'Guest User',
      email: map['email'] ?? '',
      gender: map['gender'] ?? 'Male',
      age: int.tryParse(map['age'].toString()) ?? 25,
      weight: double.tryParse(map['weight'].toString()) ?? 70.0,
      height: double.tryParse(map['height'].toString()) ?? 175.0,
      activityLevel: map['activityLevel'] ?? 'Sedentary',
      goal: map['goal'] ?? 'Lose Weight',
      dailyCalorieGoal:
          int.tryParse(map['dailyCalorieGoal'].toString()) ?? 2000,
    );
  }

  UserModel copyWith({
    String? name,
    String? email,
    String? gender,
    int? age,
    double? weight,
    double? height,
    String? activityLevel,
    String? goal,
    int? dailyCalorieGoal,
  }) {
    return UserModel(
      uid: uid,
      name: name ?? this.name,
      email: email ?? this.email,
      gender: gender ?? this.gender,
      age: age ?? this.age,
      weight: weight ?? this.weight,
      height: height ?? this.height,
      activityLevel: activityLevel ?? this.activityLevel,
      goal: goal ?? this.goal,
      dailyCalorieGoal: dailyCalorieGoal ?? this.dailyCalorieGoal,
    );
  }
}
