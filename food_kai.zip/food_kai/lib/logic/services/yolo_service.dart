import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';

class YoloService {
  Interpreter? _interpreter;
  List<String> _labels = [];
  bool isLoaded = false;

  Future<void> loadModel() async {
    try {
      final options = InterpreterOptions();
      // options.addDelegate(GpuDelegateV2()); // Optional

      _interpreter = await Interpreter.fromAsset(
        'assets/best_int8.tflite',
        options: options,
      );

      final labelsData = await rootBundle.loadString('assets/labels.txt');
      _labels = labelsData.split('\n').where((s) => s.isNotEmpty).toList();

      isLoaded = true;
      print(
        'YOLO Model Loaded. Output Shape: ${_interpreter!.getOutputTensor(0).shape}',
      );
    } catch (e) {
      print('Error loading model: $e');
    }
  }

  // Run Inference on CameraImage (YUV420)
  Future<Map<String, dynamic>?> detectOnFrame(CameraImage cameraImage) async {
    if (!isLoaded) return null;

    return await Isolate.run(() {
      return _convertYUVtoRGB(cameraImage);
    }).then((rgbBytes) {
      if (rgbBytes == null) return null;
      return _runInference(rgbBytes);
    });
  }

  // Separate method for Gallery image
  Future<Map<String, dynamic>?> detectOnImage(String imagePath) async {
    if (!isLoaded) return null;

    final imageBytes = await File(imagePath).readAsBytes();
    final image = img.decodeImage(imageBytes);
    if (image == null) return null;

    final resized = img.copyResize(image, width: 640, height: 640);
    final input = _imageToByteList(resized);

    return _runInference(input);
  }

  // Actual Inference (Main Thread)
  Map<String, dynamic>? _runInference(Uint8List inputBytes) {
    try {
      // Input: [1, 640, 640, 3] of UINT8
      // Note: We access the buffer directly.
      // tflite_flutter handles mapping Uint8List to the tensor if type matches.
      dynamic input = inputBytes.reshape([1, 640, 640, 3]);

      // Output: [1, 14, 8400]
      // Usually Float32 output
      var output = List<double>.filled(1 * 14 * 8400, 0).reshape([1, 14, 8400]);

      _interpreter!.run(input, output);

      return _parseYoloOutput(output[0]);
    } catch (e) {
      print('Inference Error: $e');
      return null;
    }
  }

  Map<String, dynamic>? _parseYoloOutput(List<dynamic> output) {
    // output structure is [14, 8400] (channels, anchors)
    int numAnchors = 8400;

    // Classes start at index 4 (0=x, 1=y, 2=w, 3=h)
    // 10 Food Classes

    double maxScore = 0.0;
    int bestClassIndex = -1;

    for (int anchor = 0; anchor < numAnchors; anchor++) {
      for (int cls = 0; cls < 10; cls++) {
        double score = output[4 + cls][anchor]; // Access [channel][anchor]
        if (score > maxScore) {
          maxScore = score;
          bestClassIndex = cls;
        }
      }
    }

    if (maxScore > 0.5 &&
        bestClassIndex != -1 &&
        bestClassIndex < _labels.length) {
      return {'label': _labels[bestClassIndex], 'confidence': maxScore};
    }

    return null;
  }

  Uint8List _imageToByteList(img.Image image) {
    // 640x640x3 direct Uint8
    final int size = 640 * 640 * 3;
    final buffer = Uint8List(size);
    int pixelIndex = 0;

    for (var i = 0; i < 640; i++) {
      for (var j = 0; j < 640; j++) {
        var pixel = image.getPixel(j, i);
        buffer[pixelIndex++] = pixel.r.toInt();
        buffer[pixelIndex++] = pixel.g.toInt();
        buffer[pixelIndex++] = pixel.b.toInt();
      }
    }
    return buffer;
  }

  // YUV420 to RGB Conversion
  static Uint8List? _convertYUVtoRGB(CameraImage image) {
    try {
      final int width = image.width;
      final int height = image.height;
      final int uvRowStride = image.planes[1].bytesPerRow;
      final int? uvPixelStride = image.planes[1].bytesPerPixel;

      var imgRGB = img.Image(width: width, height: height);

      for (int x = 0; x < width; x++) {
        for (int y = 0; y < height; y++) {
          final int uvIndex =
              uvPixelStride! * (x / 2).floor() + uvRowStride * (y / 2).floor();
          final int index = y * width + x;

          final yp = image.planes[0].bytes[index];
          final up = image.planes[1].bytes[uvIndex];
          final vp = image.planes[2].bytes[uvIndex];

          int r = (yp + vp * 1436 / 1024 - 179).round().clamp(0, 255);
          int g = (yp - up * 46549 / 131072 + 44 - vp * 93604 / 131072 + 91)
              .round()
              .clamp(0, 255);
          int b = (yp + up * 1814 / 1024 - 227).round().clamp(0, 255);

          imgRGB.setPixelRgb(x, y, r, g, b);
        }
      }

      var resized = img.copyResize(imgRGB, width: 640, height: 640);

      // Convert to flat Uint8List
      final int size = 640 * 640 * 3;
      final buffer = Uint8List(size);
      int pixelIndex = 0;

      for (var i = 0; i < 640; i++) {
        for (var j = 0; j < 640; j++) {
          var pixel = resized.getPixel(j, i);
          buffer[pixelIndex++] = pixel.r.toInt();
          buffer[pixelIndex++] = pixel.g.toInt();
          buffer[pixelIndex++] = pixel.b.toInt();
        }
      }

      return buffer;
    } catch (e) {
      print("YUV Conversion Error: $e");
      return null;
    }
  }

  void dispose() {
    _interpreter?.close();
  }
}
