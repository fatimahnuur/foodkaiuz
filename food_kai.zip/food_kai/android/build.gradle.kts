// Plugins bloki eng boshida
plugins {
    // Versiyalarni settings.gradle.kts dan oladi
    id("com.android.application") apply false
    id("com.android.library") apply false
    id("org.jetbrains.kotlin.android") apply false
    
    // Google Services uchun versiya kerak (chunki settings.gradle da yo'q)
    id("com.google.gms.google-services") apply false
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

val newBuildDir: Directory = rootProject.layout.buildDirectory.dir("../../build").get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}

subprojects {
    project.evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
// Faylning eng oxiriga qo'shing
subprojects {
    val subproject = this
    if (subproject.name != "app") {
        plugins.withType<com.android.build.gradle.api.AndroidBasePlugin> {
            configure<com.android.build.gradle.BaseExtension> {
                if (namespace == null) {
                    namespace = "com.example.food_kai.${subproject.name.replace("-", "_")}"
                }
            }
        }
    }
}
